# core of the bot

import langchain

print("Coming soon")